const API_BASE_URL = 'http://localhost:3001';

// Verificar autenticação ao carregar página protegida
async function verificarAutenticacao() {
  try {
    const response = await fetch(`${API_BASE_URL}/auth/validar`, {
      method: 'GET',
      credentials: 'include'
    });

    if (!response.ok) {
      // Não autenticado - redirecionar para login
      window.location.href = '/login.html';
      return null;
    }

    const data = await response.json();
    return data.usuario;
  } catch (error) {
    console.error('Erro ao verificar autenticação:', error);
    window.location.href = '/login.html';
    return null;
  }
}

// Carregar informações do usuário no header
async function carregarInfoUsuario() {
  const usuario = await verificarAutenticacao();
  
  if (usuario) {
    const nomeUsuario = document.getElementById('nomeUsuario');
    if (nomeUsuario) {
      nomeUsuario.textContent = `Bem-vindo, ${usuario.email}`;
    }
  }
}

// Logout
async function fazerLogout() {
  try {
    await fetch(`${API_BASE_URL}/auth/logout`, {
      method: 'POST',
      credentials: 'include'
    });
    window.location.href = '/login.html';
  } catch (error) {
    console.error('Erro ao fazer logout:', error);
  }
}

// Inicializar ao carregar página
document.addEventListener('DOMContentLoaded', () => {
  carregarInfoUsuario();
  
  const btnLogout = document.getElementById('btnLogout');
  if (btnLogout) {
    btnLogout.addEventListener('click', fazerLogout);
  }
});
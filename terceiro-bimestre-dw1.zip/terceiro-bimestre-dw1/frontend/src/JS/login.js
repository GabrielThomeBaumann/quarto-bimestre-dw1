const API_BASE_URL = 'http://localhost:3001';

document.getElementById('formLogin').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = document.getElementById('emailLogin').value;
  const senha = document.getElementById('senhaLogin').value;
  const mensagemErro = document.getElementById('mensagemErro');
  
  try {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email, senha })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      mensagemErro.textContent = data.erro || 'Erro ao fazer login';
      return;
    }
    
    // Login bem-sucedido - redirecionar conforme tipo
    if (data.usuario.tipo === 'admin') {
      window.location.href = '/menu.html';
    } else {
      window.location.href = '/index.html';
    }
  } catch (error) {
    console.error('Erro:', error);
    mensagemErro.textContent = 'Erro ao conectar com o servidor';
  }
});
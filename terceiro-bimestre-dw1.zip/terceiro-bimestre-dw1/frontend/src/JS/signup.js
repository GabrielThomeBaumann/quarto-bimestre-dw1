const API_BASE_URL = 'http://localhost:3001';

document.getElementById('formSignup').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = document.getElementById('emailSignup').value;
  const senha = document.getElementById('senhaSignup').value;
  const nome_completo = document.getElementById('nome_completo').value;
  const telefone = document.getElementById('telefone').value;
  const endereco = document.getElementById('endereco').value;
  const data_nascimento = document.getElementById('data_nascimento').value;
  const tipo = document.getElementById('tipoUsuario').value;
  const mensagemErro = document.getElementById('mensagemErroSignup');
  
  try {
    const response = await fetch(`${API_BASE_URL}/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ 
        email, 
        senha, 
        nome_completo, 
        telefone, 
        endereco, 
        data_nascimento, 
        tipo 
      })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      mensagemErro.textContent = data.erro || 'Erro ao criar conta';
      return;
    }
    
    // Conta criada com sucesso - redirecionar
    if (data.usuario.tipo === 'admin') {
      window.location.href = '/menu.html';
    } else {
      window.location.href = '/index.html';
    }
  } catch (error) {
    console.error('Erro:', error);
    mensagemErro.textContent = 'Erro ao conectar com o servidor';
  }
});
const jwt = require('jsonwebtoken');

const JWT_SECRET = 'sua_chave_secreta_super_segura_2025'; // Mude para variável de ambiente

// Middleware para verificar se o usuário está autenticado
exports.verificarAutenticacao = (req, res, next) => {
  const token = req.cookies.authToken;
  
  if (!token) {
    return res.status(401).json({ erro: 'Não autenticado' });
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.usuario = decoded;
    next();
  } catch (error) {
    res.clearCookie('authToken');
    return res.status(401).json({ erro: 'Token inválido' });
  }
};

// Middleware para verificar se é admin
exports.verificarAdmin = (req, res, next) => {
  if (req.usuario.tipo !== 'admin') {
    return res.status(403).json({ erro: 'Acesso negado. Apenas administradores.' });
  }
  next();
};
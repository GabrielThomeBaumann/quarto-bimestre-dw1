const { query, transaction } = require('../database');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const JWT_SECRET = 'sua_chave_secreta_super_segura_2025';
const JWT_EXPIRES = '7d';

// Signup - Criar novo usuário E perfil
exports.signup = async (req, res) => {
  try {
    const { email, senha, nome_completo, telefone, endereco, data_nascimento, tipo } = req.body;

    if (!email || !senha || !nome_completo) {
      return res.status(400).json({ erro: 'Email, senha e nome completo são obrigatórios' });
    }

    // Verificar se email já existe
    const resultExists = await query('SELECT * FROM usuarios WHERE email = $1', [email]);
    if (resultExists.rows.length > 0) {
      return res.status(400).json({ erro: 'Email já cadastrado' });
    }

    // Hash da senha
    const senhaHash = await bcrypt.hash(senha, 10);

    // Usar transação para inserir em ambas as tabelas
    await transaction(async (client) => {
      // Inserir em usuarios
      const resultUsuario = await client.query(
        'INSERT INTO usuarios (email, senha, tipo) VALUES ($1, $2, $3) RETURNING usuario_id, email, tipo',
        [email, senhaHash, tipo || 'comum']
      );

      const usuario = resultUsuario.rows[0];

      // Inserir em perfis
      await client.query(
        'INSERT INTO perfis (usuario_id, nome_completo, telefone, endereco, data_nascimento) VALUES ($1, $2, $3, $4, $5)',
        [usuario.usuario_id, nome_completo, telefone || null, endereco || null, data_nascimento || null]
      );

      // Gerar JWT
      const token = jwt.sign(
        { usuario_id: usuario.usuario_id, email: usuario.email, tipo: usuario.tipo },
        JWT_SECRET,
        { expiresIn: JWT_EXPIRES }
      );

      res.cookie('authToken', token, {
        httpOnly: true,
        secure: false,
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000
      });

      res.status(201).json({
        mensagem: 'Usuário criado com sucesso',
        usuario: { usuario_id: usuario.usuario_id, email: usuario.email, tipo: usuario.tipo }
      });
    });
  } catch (error) {
    console.error('Erro ao fazer signup:', error);
    res.status(500).json({ erro: 'Erro interno do servidor' });
  }
};

// Login - Autenticar usuário existente
exports.login = async (req, res) => {
  try {
    const { email, senha } = req.body;

    if (!email || !senha) {
      return res.status(400).json({ erro: 'Email e senha são obrigatórios' });
    }

    // Buscar usuário
    const result = await query('SELECT * FROM usuarios WHERE email = $1', [email]);
    if (result.rows.length === 0) {
      return res.status(401).json({ erro: 'Email ou senha incorretos' });
    }

    const usuario = result.rows[0];

    // Verificar senha
    const senhaValida = await bcrypt.compare(senha, usuario.senha);
    if (!senhaValida) {
      return res.status(401).json({ erro: 'Email ou senha incorretos' });
    }

    // Gerar JWT
    const token = jwt.sign(
      { usuario_id: usuario.usuario_id, email: usuario.email, tipo: usuario.tipo },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES }
    );

    res.cookie('authToken', token, {
      httpOnly: true,
      secure: false,
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    res.json({
      mensagem: 'Login bem-sucedido',
      usuario: { usuario_id: usuario.usuario_id, email: usuario.email, tipo: usuario.tipo }
    });
  } catch (error) {
    console.error('Erro ao fazer login:', error);
    res.status(500).json({ erro: 'Erro interno do servidor' });
  }
};

// Validar autenticação
exports.validarAuth = (req, res) => {
  try {
    res.json({
      autenticado: true,
      usuario: req.usuario
    });
  } catch (error) {
    res.status(401).json({ autenticado: false });
  }
};

// Logout
exports.logout = (req, res) => {
  res.clearCookie('authToken');
  res.json({ mensagem: 'Logout bem-sucedido' });
};